import base64
import io
import json
import logging
from datetime import datetime
from pathlib import Path

import anthropic
import pdfplumber
from PIL import Image

from server.config import (
    ANTHROPIC_API_KEY,
    ANTHROPIC_MODEL_IMAGE_PARSE,
    ANTHROPIC_MODEL_PDF_PARSE,
)

logger = logging.getLogger(__name__)

_PROMPT = """이 영수증/인보이스에서 다음 정보를 JSON으로 추출해주세요:
{
  "merchant_name": "가맹점/업체명",
  "date": "YYYY-MM-DD",
  "time": "HH:MM (있는 경우, 없으면 null)",
  "total_amount": 숫자,
  "currency": "AUD 또는 기타 통화코드",
  "gst_amount": 숫자 (있는 경우, 없으면 null),
  "category_guess": "식비/교통/숙박/서비스구독/사무용품/기타 중 하나",
  "confidence": "high/medium/low"
}
영수증이 아닌 경우 {"error": "not_a_receipt"} 를 반환하세요.
JSON만 반환하고 다른 설명은 포함하지 마세요.

[날짜 형식 주의]
이 영수증은 호주(Australia)에서 발행된 것입니다.
호주는 DD/MM/YYYY 형식을 사용합니다 (일/월/년도 순서).
예: 영수증의 "05/01"은 5월 1일이 아닌 1월 5일(January 5th)입니다.
사용자 메시지에 포함된 업로드 일시를 참고하여 연도나 월이 불확실한 경우 검증하세요."""

_EXT_TO_MEDIA_TYPE = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
}


_MAX_IMAGE_PX = 1568  # Anthropic 권장 최대 크기


def _prepare_image_bytes(image_path: Path) -> tuple[bytes, str]:
    """이미지를 1568px 이하로 리사이즈하고 JPEG로 반환해 메모리 사용량을 줄인다."""
    with Image.open(image_path) as img:
        if img.mode in ("RGBA", "P", "LA"):
            img = img.convert("RGB")
        w, h = img.size
        if w > _MAX_IMAGE_PX or h > _MAX_IMAGE_PX:
            ratio = min(_MAX_IMAGE_PX / w, _MAX_IMAGE_PX / h)
            img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=85, optimize=True)
        return buf.getvalue(), "image/jpeg"


def _make_client() -> anthropic.Anthropic:
    if not ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY가 설정되지 않았습니다.")
    return anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)


def _strip_fence(raw: str) -> str:
    raw = raw.strip()
    if raw.startswith("```"):
        lines = raw.split("\n")
        raw = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])
    return raw


def parse_image(image_path: Path, upload_dt: datetime | None = None) -> dict:
    """이미지를 Claude Vision API로 파싱하여 결과 dict 반환."""
    image_bytes, media_type = _prepare_image_bytes(image_path)
    image_data = base64.standard_b64encode(image_bytes).decode("utf-8")

    dt_str = (upload_dt or datetime.now()).strftime("%Y-%m-%d %H:%M")

    client = _make_client()
    message = client.messages.create(
        model=ANTHROPIC_MODEL_IMAGE_PARSE,
        max_tokens=1024,
        system=_PROMPT,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": f"업로드 일시: {dt_str} (AEST)",
                },
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": image_data,
                    },
                },
            ],
        }],
    )

    raw = _strip_fence(message.content[0].text)
    parsed = json.loads(raw)
    logger.info("이미지 파싱 결과: %s", json.dumps(parsed, ensure_ascii=False))
    return parsed


def _parse_pdf_text(client: anthropic.Anthropic, text: str, dt_str: str) -> dict:
    message = client.messages.create(
        model=ANTHROPIC_MODEL_PDF_PARSE,
        max_tokens=1024,
        system=_PROMPT,
        messages=[{
            "role": "user",
            "content": f"업로드 일시: {dt_str} (AEST)\n\n아래는 PDF에서 추출한 텍스트입니다:\n\n{text}",
        }],
    )
    raw = _strip_fence(message.content[0].text)
    return json.loads(raw)


def _parse_pdf_vision(client: anthropic.Anthropic, pdf_path: Path, dt_str: str) -> dict:
    size_mb = pdf_path.stat().st_size / (1024 * 1024)
    if size_mb > 8:
        raise ValueError(f"PDF 크기가 너무 큽니다 ({size_mb:.1f}MB). 8MB 이하 파일만 지원합니다.")

    with open(pdf_path, "rb") as f:
        pdf_data = base64.standard_b64encode(f.read()).decode("utf-8")

    message = client.messages.create(
        model=ANTHROPIC_MODEL_PDF_PARSE,
        max_tokens=1024,
        system=_PROMPT,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": f"업로드 일시: {dt_str} (AEST)",
                },
                {
                    "type": "document",
                    "source": {
                        "type": "base64",
                        "media_type": "application/pdf",
                        "data": pdf_data,
                    },
                },
            ],
        }],
    )
    raw = _strip_fence(message.content[0].text)
    return json.loads(raw)


def parse_pdf(pdf_path: Path, upload_dt: datetime | None = None) -> dict:
    """PDF를 pdfplumber + Claude API로 파싱. 스캔 PDF는 Vision API 폴백."""
    client = _make_client()
    dt_str = (upload_dt or datetime.now()).strftime("%Y-%m-%d %H:%M")

    parts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                parts.append(text)
    pdf_text = "\n\n".join(parts).strip()

    if pdf_text:
        logger.info("PDF 텍스트 추출 성공 (%d자): %s", len(pdf_text), pdf_path.name)
        parsed = _parse_pdf_text(client, pdf_text, dt_str)
    else:
        logger.info("PDF 텍스트 추출 실패, Vision 폴백: %s", pdf_path.name)
        parsed = _parse_pdf_vision(client, pdf_path, dt_str)

    logger.info("PDF 파싱 결과: %s", json.dumps(parsed, ensure_ascii=False))
    return parsed
