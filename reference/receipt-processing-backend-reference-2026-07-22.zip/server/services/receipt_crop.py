import base64
import json
import logging
import math
import uuid
from collections.abc import Callable
from pathlib import Path

from PIL import Image, UnidentifiedImageError

from server import config


logger = logging.getLogger(__name__)


class CropValidationError(ValueError):
    pass


class UnsupportedCropSourceError(ValueError):
    pass


class AutoCropFailedError(RuntimeError):
    pass


_SUPPORTED_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}
_MAX_ROTATION_DEGREES = 360
_EXT_TO_MEDIA_TYPE = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}
_AUTO_CROP_PROMPT = """Find the four physical corners of the receipt paper in this image.

Return JSON only:
{
  "top_left": {"x": number, "y": number},
  "top_right": {"x": number, "y": number},
  "bottom_right": {"x": number, "y": number},
  "bottom_left": {"x": number, "y": number}
}

If a receipt paper cannot be found, return {"error": "not_found"}.
Use the outer paper boundary, not the text boundary. Include the bottom of the physical paper even when small card/payment text appears near the bottom.
"""


def create_manual_crop(
    source_path: Path,
    x: float,
    y: float,
    width: float,
    height: float,
    rotation_degrees: float = 0,
) -> Path:
    if source_path.suffix.lower() not in _SUPPORTED_IMAGE_SUFFIXES:
        raise UnsupportedCropSourceError("manual crop supports image originals only")
    if not source_path.exists():
        raise FileNotFoundError(source_path)
    rotation = _validate_rotation(rotation_degrees)

    try:
        with Image.open(source_path) as image:
            image.load()
            if rotation:
                image = image.rotate(-rotation, expand=True)
            crop_box = _validate_crop_rect(
                x=x,
                y=y,
                width=width,
                height=height,
                image_width=image.width,
                image_height=image.height,
            )
            cropped = image.crop(crop_box)
            if cropped.mode not in ("RGB", "L"):
                cropped = cropped.convert("RGB")

            output_path = _manual_crop_path(source_path)
            cropped.save(output_path, format="JPEG", quality=95)
            return output_path
    except UnidentifiedImageError as exc:
        raise UnsupportedCropSourceError("original file is not a supported image") from exc


def create_auto_crop(
    source_path: Path,
    *,
    corner_detector: Callable[[Path], dict | None] | None = None,
) -> Path:
    if source_path.suffix.lower() not in _SUPPORTED_IMAGE_SUFFIXES:
        raise UnsupportedCropSourceError("auto crop supports image originals only")
    if not source_path.exists():
        raise FileNotFoundError(source_path)

    detector = corner_detector or _detect_receipt_corners
    corners = detector(source_path)
    if corners is None:
        raise AutoCropFailedError("receipt corners could not be detected")

    try:
        import cv2
    except ImportError as exc:
        raise AutoCropFailedError("auto crop image backend is not installed") from exc

    image = cv2.imread(str(source_path))
    if image is None:
        raise UnsupportedCropSourceError("original file is not a supported image")

    height, width = image.shape[:2]
    normalised_corners = _normalise_corners(corners, width, height)
    expanded_corners = _expand_corners(normalised_corners, width, height, pad_px=20)
    warped = _perspective_transform(image, expanded_corners)
    if warped.shape[0] < 50 or warped.shape[1] < 50:
        raise AutoCropFailedError("auto crop result is too small")

    output_path = _auto_crop_path(source_path)
    if not cv2.imwrite(str(output_path), warped):
        raise AutoCropFailedError("auto crop output could not be saved")
    return output_path


def _validate_rotation(rotation_degrees: float) -> float:
    if not math.isfinite(rotation_degrees):
        raise CropValidationError("rotation must be a finite number")
    if abs(rotation_degrees) > _MAX_ROTATION_DEGREES:
        raise CropValidationError("rotation must be between -360 and 360 degrees")
    return rotation_degrees % 360


def _validate_crop_rect(
    x: float,
    y: float,
    width: float,
    height: float,
    image_width: int,
    image_height: int,
) -> tuple[int, int, int, int]:
    values = (x, y, width, height)
    if not all(math.isfinite(value) for value in values):
        raise CropValidationError("crop values must be finite numbers")
    if x < 0 or y < 0:
        raise CropValidationError("crop origin must be inside image bounds")
    if width <= 0 or height <= 0:
        raise CropValidationError("crop width and height must be positive")
    if x + width > image_width or y + height > image_height:
        raise CropValidationError("crop rectangle is outside image bounds")

    left = int(round(x))
    top = int(round(y))
    right = int(round(x + width))
    bottom = int(round(y + height))
    if right <= left or bottom <= top:
        raise CropValidationError("crop rectangle is too small")
    if right > image_width or bottom > image_height:
        raise CropValidationError("crop rectangle is outside image bounds")
    return left, top, right, bottom


def _manual_crop_path(source_path: Path) -> Path:
    suffix = f"_manual_crop_{uuid.uuid4().hex}.jpg"
    return source_path.with_name(f"{source_path.stem}{suffix}")


def _auto_crop_path(source_path: Path) -> Path:
    suffix = f"_auto_crop_{uuid.uuid4().hex}.jpg"
    return source_path.with_name(f"{source_path.stem}{suffix}")


def _detect_receipt_corners(image_path: Path) -> dict | None:
    if not config.ANTHROPIC_API_KEY:
        raise AutoCropFailedError("auto crop API key is not configured")

    try:
        import anthropic
    except ImportError as exc:
        raise AutoCropFailedError("auto crop API client is not installed") from exc

    media_type = _EXT_TO_MEDIA_TYPE.get(image_path.suffix.lower(), "image/jpeg")
    image_data = base64.standard_b64encode(image_path.read_bytes()).decode("utf-8")
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY, timeout=25.0)
    try:
        message = client.messages.create(
            model=config.ANTHROPIC_MODEL_CROP_DETECT,
            max_tokens=128,
            system=_AUTO_CROP_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_data,
                            },
                        }
                    ],
                }
            ],
        )
    except Exception as exc:
        logger.warning("auto crop corner detection failed", exc_info=True)
        raise AutoCropFailedError("auto crop corner detection failed") from exc

    raw = message.content[0].text.strip()
    if raw.startswith("```"):
        lines = raw.split("\n")
        raw = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.warning("auto crop corner response was not valid JSON")
        raise AutoCropFailedError("auto crop corner response was not valid JSON") from exc

    if "error" in data:
        return None
    required = {"top_left", "top_right", "bottom_right", "bottom_left"}
    if not required.issubset(data):
        raise AutoCropFailedError("auto crop corner response was incomplete")
    return data


def _normalise_corners(corners: dict, width: int, height: int) -> dict:
    normalised = {}
    for key in ("top_left", "top_right", "bottom_right", "bottom_left"):
        point = corners.get(key)
        if not isinstance(point, dict):
            raise AutoCropFailedError("auto crop corner response was incomplete")
        try:
            x = int(point["x"])
            y = int(point["y"])
        except (KeyError, TypeError, ValueError) as exc:
            raise AutoCropFailedError("auto crop corner response was invalid") from exc
        normalised[key] = {
            "x": max(0, min(width - 1, x)),
            "y": max(0, min(height - 1, y)),
        }
    return normalised


def _expand_corners(corners: dict, width: int, height: int, pad_px: int = 20) -> dict:
    cx = sum(point["x"] for point in corners.values()) / 4
    cy = sum(point["y"] for point in corners.values()) / 4
    bottom_extra = max(100, int(height * 0.10))
    expanded = {}
    for key, point in corners.items():
        dx = point["x"] - cx
        dy = point["y"] - cy
        dist = max((dx**2 + dy**2) ** 0.5, 1)
        new_x = max(0, min(width - 1, int(point["x"] + pad_px * dx / dist)))
        new_y = max(0, min(height - 1, int(point["y"] + pad_px * dy / dist)))
        if key in ("bottom_left", "bottom_right"):
            new_y = max(0, min(height - 1, new_y + bottom_extra))
        expanded[key] = {"x": new_x, "y": new_y}
    return expanded


def _perspective_transform(image, corners: dict):
    import cv2
    import numpy as np

    tl = np.array([corners["top_left"]["x"], corners["top_left"]["y"]], dtype="float32")
    tr = np.array([corners["top_right"]["x"], corners["top_right"]["y"]], dtype="float32")
    br = np.array([corners["bottom_right"]["x"], corners["bottom_right"]["y"]], dtype="float32")
    bl = np.array([corners["bottom_left"]["x"], corners["bottom_left"]["y"]], dtype="float32")

    width = int(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl)))
    height = int(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr)))
    if width <= 1 or height <= 1:
        raise AutoCropFailedError("auto crop corner geometry was invalid")

    src = np.array([tl, tr, br, bl], dtype="float32")
    dst = np.array(
        [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        dtype="float32",
    )
    matrix = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(
        image,
        matrix,
        (width, height),
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(255, 255, 255),
    )
