from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import FileResponse
from pydantic import BaseModel

from server.routers.auth import get_current_user
from server.services import audit, db, receipt_crop

router = APIRouter(prefix="/api/receipts", tags=["receipts"])

_CONTENT_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".pdf": "application/pdf",
}

_RECEIPT_NOT_FOUND = "Receipt not found or access denied."
_FILE_PATH_MISSING = "Receipt file path is missing."
_FILE_NOT_FOUND = "Receipt file does not exist."
_NO_STORE_HEADERS = {
    "Cache-Control": "no-store",
    "Pragma": "no-cache",
    "Expires": "0",
}


class ManualCropRequest(BaseModel):
    x: float
    y: float
    width: float
    height: float
    rotation_degrees: float = 0


class ReceiptCropActionResponse(BaseModel):
    id: int
    message: str
    preview_url: str


ManualCropResponse = ReceiptCropActionResponse


def _authorized_user_id(current_user: dict) -> int | None:
    return None if current_user.get("is_admin") else current_user["id"]


def _get_authorized_receipt(receipt_id: int, current_user: dict) -> dict:
    receipt = db.get_receipt_for_preview(
        receipt_id,
        _authorized_user_id(current_user),
    )
    if not receipt:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_RECEIPT_NOT_FOUND,
        )
    return receipt


def _file_response(file_path: str) -> FileResponse:
    path = Path(file_path)
    if not path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_NOT_FOUND,
        )

    content_type = _CONTENT_TYPES.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(str(path), media_type=content_type, headers=_NO_STORE_HEADERS)


@router.get("/{receipt_id}/preview")
async def receipt_preview(
    receipt_id: int,
    current_user: dict = Depends(get_current_user),
) -> FileResponse:
    receipt = _get_authorized_receipt(receipt_id, current_user)

    file_path = receipt.get("cropped_file_path") or receipt.get("file_path")
    if not file_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_PATH_MISSING,
        )

    return _file_response(file_path)


@router.get("/{receipt_id}/original")
async def receipt_original(
    receipt_id: int,
    current_user: dict = Depends(get_current_user),
) -> FileResponse:
    receipt = _get_authorized_receipt(receipt_id, current_user)

    file_path = receipt.get("file_path")
    if not file_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_PATH_MISSING,
        )

    return _file_response(file_path)


@router.post("/{receipt_id}/crop", response_model=ManualCropResponse)
async def manual_crop_receipt(
    receipt_id: int,
    req: ManualCropRequest,
    current_user: dict = Depends(get_current_user),
) -> ManualCropResponse:
    receipt = _get_authorized_receipt(receipt_id, current_user)

    file_path = receipt.get("file_path")
    if not file_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_PATH_MISSING,
        )

    try:
        output_path = receipt_crop.create_manual_crop(
            Path(file_path),
            x=req.x,
            y=req.y,
            width=req.width,
            height=req.height,
            rotation_degrees=req.rotation_degrees,
        )
    except receipt_crop.CropValidationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except receipt_crop.UnsupportedCropSourceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_NOT_FOUND,
        ) from exc

    updated = db.update_receipt_cropped_file_path(
        receipt_id=receipt_id,
        cropped_file_path=str(output_path),
        user_id=_authorized_user_id(current_user),
    )
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_RECEIPT_NOT_FOUND,
        )

    return ManualCropResponse(
        id=receipt_id,
        message="manual crop saved",
        preview_url=f"/api/receipts/{receipt_id}/preview",
    )


@router.post("/{receipt_id}/auto-crop", response_model=ReceiptCropActionResponse)
async def auto_crop_receipt(
    receipt_id: int,
    request: Request,
    current_user: dict = Depends(get_current_user),
) -> ReceiptCropActionResponse:
    receipt = _get_authorized_receipt(receipt_id, current_user)

    file_path = receipt.get("file_path")
    if not file_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_PATH_MISSING,
        )

    try:
        output_path = receipt_crop.create_auto_crop(Path(file_path))
    except receipt_crop.AutoCropFailedError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    except receipt_crop.UnsupportedCropSourceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_FILE_NOT_FOUND,
        ) from exc

    updated = db.update_receipt_cropped_file_path(
        receipt_id=receipt_id,
        cropped_file_path=str(output_path),
        user_id=_authorized_user_id(current_user),
    )
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_RECEIPT_NOT_FOUND,
        )

    audit.record_event(
        event_type=audit.EVENT_RECEIPT_CROP_AUTO_RERUN,
        actor_user_id=current_user.get("id"),
        actor_role=audit.actor_role(current_user),
        target_type="receipt",
        target_id=receipt_id,
        request=request,
    )
    return ReceiptCropActionResponse(
        id=receipt_id,
        message="auto crop rerun saved",
        preview_url=f"/api/receipts/{receipt_id}/preview",
    )


@router.post("/{receipt_id}/reset-crop", response_model=ReceiptCropActionResponse)
async def reset_receipt_crop(
    receipt_id: int,
    request: Request,
    current_user: dict = Depends(get_current_user),
) -> ReceiptCropActionResponse:
    _get_authorized_receipt(receipt_id, current_user)

    updated = db.update_receipt_cropped_file_path(
        receipt_id=receipt_id,
        cropped_file_path=None,
        user_id=_authorized_user_id(current_user),
    )
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_RECEIPT_NOT_FOUND,
        )

    audit.record_event(
        event_type=audit.EVENT_RECEIPT_CROP_RESET,
        actor_user_id=current_user.get("id"),
        actor_role=audit.actor_role(current_user),
        target_type="receipt",
        target_id=receipt_id,
        request=request,
    )
    return ReceiptCropActionResponse(
        id=receipt_id,
        message="crop reset to original",
        preview_url=f"/api/receipts/{receipt_id}/preview",
    )
