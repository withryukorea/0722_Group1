import logging
import os

from dotenv import load_dotenv

_INITIAL_APP_ENV = os.getenv("APP_ENV", "development").strip().lower()
if _INITIAL_APP_ENV != "test":
    load_dotenv()

APP_ENV: str = os.getenv("APP_ENV", "development").strip().lower()
PRODUCTION_APP_ENVS: set[str] = {"production", "prod", "staging", "uat"}
DEFAULT_JWT_SECRET: str = "dev-secret-change-in-production"
UNSAFE_JWT_SECRETS: set[str] = {
    "",
    DEFAULT_JWT_SECRET,
    "change-this-to-a-random-secret-string",
    "your_jwt_secret",
}
MIN_JWT_SECRET_LENGTH: int = 32
DEV_CORS_ALLOW_ORIGINS: list[str] = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

DB_PATH: str = os.getenv("DB_PATH", "data/receipt_manager.db")
RECEIPT_STORAGE_DIR: str = os.getenv("RECEIPT_STORAGE_DIR", "data/receipts/")
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
DEFAULT_ANTHROPIC_MODEL: str = "claude-sonnet-4-6"


def _optional_env(key: str, default: str) -> str:
    return os.getenv(key, default).strip() or default


ANTHROPIC_MODEL_IMAGE_PARSE: str = _optional_env(
    "ANTHROPIC_MODEL_IMAGE_PARSE",
    DEFAULT_ANTHROPIC_MODEL,
)
ANTHROPIC_MODEL_PDF_PARSE: str = _optional_env(
    "ANTHROPIC_MODEL_PDF_PARSE",
    DEFAULT_ANTHROPIC_MODEL,
)
ANTHROPIC_MODEL_CROP_DETECT: str = _optional_env(
    "ANTHROPIC_MODEL_CROP_DETECT",
    DEFAULT_ANTHROPIC_MODEL,
)

TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
ADMIN_TELEGRAM_ID: int = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))

JWT_SECRET: str = os.getenv("JWT_SECRET", DEFAULT_JWT_SECRET).strip()
JWT_ALGORITHM: str = "HS256"
JWT_EXPIRE_MINUTES: int = int(os.getenv("JWT_EXPIRE_MINUTES", "480"))  # 8시간
LOGIN_FAILURE_LIMIT: int = int(os.getenv("LOGIN_FAILURE_LIMIT", "5"))
LOGIN_FAILURE_WINDOW_SECONDS: int = int(os.getenv("LOGIN_FAILURE_WINDOW_SECONDS", "300"))
LOGIN_LOCKOUT_SECONDS: int = int(os.getenv("LOGIN_LOCKOUT_SECONDS", "900"))
LOGIN_FAILURE_STATE_LIMIT: int = int(os.getenv("LOGIN_FAILURE_STATE_LIMIT", "1024"))
AUDIT_HASH_SECRET: str = os.getenv("AUDIT_HASH_SECRET", "").strip()

def _parse_bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_csv_env(name: str) -> list[str] | None:
    value = os.getenv(name)
    if value is None:
        return None
    return [item.strip() for item in value.split(",") if item.strip()]


def _default_api_docs_enabled(app_env: str) -> bool:
    return app_env not in PRODUCTION_APP_ENVS


def _default_cors_allow_origins(app_env: str) -> list[str]:
    if app_env in PRODUCTION_APP_ENVS:
        return []
    return DEV_CORS_ALLOW_ORIGINS


API_DOCS_ENABLED: bool = _parse_bool_env(
    "API_DOCS_ENABLED",
    _default_api_docs_enabled(APP_ENV),
)
CORS_ALLOW_ORIGINS: list[str] = (
    _parse_csv_env("CORS_ALLOW_ORIGINS")
    or _default_cors_allow_origins(APP_ENV)
)


def _validate_jwt_secret(secret: str, app_env: str) -> None:
    if app_env not in PRODUCTION_APP_ENVS:
        return

    if secret in UNSAFE_JWT_SECRETS or len(secret) < MIN_JWT_SECRET_LENGTH:
        raise RuntimeError(
            f"Unsafe JWT_SECRET for APP_ENV={app_env}. "
            f"Set JWT_SECRET to a random value with at least {MIN_JWT_SECRET_LENGTH} characters."
        )


_validate_jwt_secret(JWT_SECRET, APP_ENV)

if JWT_SECRET in UNSAFE_JWT_SECRETS:
    logging.getLogger(__name__).warning(
        "JWT_SECRET가 기본값입니다. 프로덕션에서는 .env에 JWT_SECRET를 설정하세요."
    )
