import io
import sqlite3
from pathlib import Path

from PIL import Image
import pytest


def _login(client, employee_id: str) -> dict[str, str]:
    response = client.post(
        "/api/auth/login",
        json={"employee_id": employee_id, "password": employee_id},
    )
    assert response.status_code == 200
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def _create_receipts_table(db_path: Path) -> None:
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                card_last4 TEXT NOT NULL,
                receipt_date DATE,
                file_type TEXT NOT NULL,
                file_path TEXT NOT NULL,
                cropped_file_path TEXT,
                original_filename TEXT,
                match_status TEXT DEFAULT 'unmatched',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def _insert_user(db_path: Path, employee_id: str, card_last4: str, is_admin: int = 0) -> int:
    with sqlite3.connect(db_path) as conn:
        cursor = conn.execute(
            """
            INSERT INTO users (
                telegram_user_id, telegram_username, employee_id,
                card_last4, display_name, is_approved, is_admin,
                password_changed
            ) VALUES (?, ?, ?, ?, ?, 1, ?, 1)
            """,
            (int(card_last4), None, employee_id, card_last4, None, is_admin),
        )
        return cursor.lastrowid


def _save_image(path: Path, size: tuple[int, int] = (100, 80)) -> None:
    image = Image.new("RGB", size, "white")
    for x in range(10, min(60, size[0])):
        for y in range(20, min(70, size[1])):
            image.putpixel((x, y), (20, 120, 200))
    image.save(path)


def _save_solid_image(path: Path, color: tuple[int, int, int], size: tuple[int, int]) -> None:
    Image.new("RGB", size, color).save(path)


def _save_quadrant_image(path: Path) -> None:
    image = Image.new("RGB", (4, 3), "white")
    colors = {
        (0, 0): (255, 0, 0),
        (1, 0): (0, 255, 0),
        (2, 0): (0, 0, 255),
        (3, 0): (255, 255, 0),
        (0, 1): (255, 0, 255),
        (1, 1): (0, 255, 255),
        (2, 1): (64, 64, 64),
        (3, 1): (255, 128, 0),
        (0, 2): (128, 0, 255),
        (1, 2): (0, 128, 255),
        (2, 2): (128, 255, 0),
        (3, 2): (0, 0, 0),
    }
    for point, color in colors.items():
        image.putpixel(point, color)
    image.save(path)


def _insert_receipt(
    db_path: Path,
    user_id: int,
    card_last4: str,
    file_path: Path,
    cropped_file_path: Path | None = None,
) -> int:
    with sqlite3.connect(db_path) as conn:
        cursor = conn.execute(
            """
            INSERT INTO receipts (
                user_id, card_last4, receipt_date, file_type,
                file_path, cropped_file_path, original_filename
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                card_last4,
                "2026-06-23",
                "image",
                str(file_path),
                str(cropped_file_path) if cropped_file_path else None,
                "synthetic-original.png",
            ),
        )
        return cursor.lastrowid


def _receipt_crop_path(db_path: Path, receipt_id: int) -> str | None:
    with sqlite3.connect(db_path) as conn:
        return conn.execute(
            "SELECT cropped_file_path FROM receipts WHERE id = ?",
            (receipt_id,),
        ).fetchone()[0]


def _audit_event(db_path: Path, event_type: str) -> dict:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            """
            SELECT event_type, actor_role, target_type, target_id, metadata_json
            FROM audit_events
            WHERE event_type = ?
            ORDER BY id DESC
            LIMIT 1
            """,
            (event_type,),
        ).fetchone()
        assert row is not None
        return dict(row)


def test_owner_can_fetch_original_and_create_manual_crop_without_path_leak(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    previous_crop = tmp_path / "synthetic-previous-crop.jpg"
    _save_image(original)
    _save_image(previous_crop, size=(12, 12))
    receipt_id = _insert_receipt(
        isolated_app["db_path"],
        owner_id,
        "1001",
        original,
        previous_crop,
    )

    original_response = client.get(f"/api/receipts/{receipt_id}/original", headers=headers)
    assert original_response.status_code == 200
    with Image.open(io.BytesIO(original_response.content)) as image:
        assert image.size == (100, 80)

    crop_response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 10, "y": 20, "width": 30, "height": 40},
    )

    assert crop_response.status_code == 200
    body = crop_response.json()
    assert body == {
        "id": receipt_id,
        "message": "manual crop saved",
        "preview_url": f"/api/receipts/{receipt_id}/preview",
    }
    assert str(tmp_path) not in str(body)
    assert original.exists()
    assert previous_crop.exists()

    new_crop = Path(_receipt_crop_path(isolated_app["db_path"], receipt_id))
    assert new_crop.exists()
    assert new_crop != previous_crop
    with Image.open(new_crop) as image:
        assert image.size == (30, 40)


def test_preview_returns_latest_manual_crop_with_no_store_headers(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    previous_crop = tmp_path / "synthetic-previous-crop.png"
    _save_image(original)
    _save_solid_image(previous_crop, (200, 30, 30), (16, 16))
    receipt_id = _insert_receipt(
        isolated_app["db_path"],
        owner_id,
        "1001",
        original,
        previous_crop,
    )

    before_response = client.get(f"/api/receipts/{receipt_id}/preview", headers=headers)
    assert before_response.status_code == 200
    with Image.open(io.BytesIO(before_response.content)) as image:
        assert image.size == (16, 16)
        assert image.getpixel((0, 0)) == (200, 30, 30)

    crop_response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 10, "y": 20, "width": 30, "height": 40},
    )
    assert crop_response.status_code == 200

    after_response = client.get(f"/api/receipts/{receipt_id}/preview", headers=headers)
    assert after_response.status_code == 200
    assert after_response.headers["cache-control"] == "no-store"
    assert after_response.headers["pragma"] == "no-cache"
    assert after_response.headers["expires"] == "0"
    assert after_response.content != before_response.content
    with Image.open(io.BytesIO(after_response.content)) as image:
        assert image.size == (30, 40)
        red, green, blue = image.getpixel((0, 0))
        assert 15 <= red <= 25
        assert 115 <= green <= 125
        assert 195 <= blue <= 205


def test_reset_crop_restores_original_preview_without_deleting_files(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    previous_crop = tmp_path / "synthetic-previous-crop.png"
    _save_solid_image(original, (20, 120, 200), (100, 80))
    _save_solid_image(previous_crop, (200, 30, 30), (16, 16))
    receipt_id = _insert_receipt(
        isolated_app["db_path"],
        owner_id,
        "1001",
        original,
        previous_crop,
    )

    response = client.post(f"/api/receipts/{receipt_id}/reset-crop", headers=headers)

    assert response.status_code == 200
    assert response.json() == {
        "id": receipt_id,
        "message": "crop reset to original",
        "preview_url": f"/api/receipts/{receipt_id}/preview",
    }
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None
    assert original.exists()
    assert previous_crop.exists()
    assert _audit_event(isolated_app["db_path"], "receipt.crop.reset") == {
        "event_type": "receipt.crop.reset",
        "actor_role": "user",
        "target_type": "receipt",
        "target_id": receipt_id,
        "metadata_json": "{}",
    }

    preview_response = client.get(f"/api/receipts/{receipt_id}/preview", headers=headers)
    assert preview_response.status_code == 200
    assert preview_response.headers["cache-control"] == "no-store"
    with Image.open(io.BytesIO(preview_response.content)) as image:
        assert image.size == (100, 80)
        red, green, blue = image.getpixel((0, 0))
        assert 15 <= red <= 25
        assert 115 <= green <= 125
        assert 195 <= blue <= 205

    second_response = client.post(f"/api/receipts/{receipt_id}/reset-crop", headers=headers)
    assert second_response.status_code == 200
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None


def test_auto_crop_rerun_updates_preview_from_original_without_deleting_files(
    isolated_app,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    previous_crop = tmp_path / "synthetic-previous-crop.png"
    _save_solid_image(original, (20, 120, 200), (100, 80))
    _save_solid_image(previous_crop, (200, 30, 30), (16, 16))
    receipt_id = _insert_receipt(
        isolated_app["db_path"],
        owner_id,
        "1001",
        original,
        previous_crop,
    )

    def fake_auto_crop(source_path: Path) -> Path:
        assert source_path == original
        new_crop = tmp_path / "synthetic-auto-rerun.jpg"
        _save_solid_image(new_crop, (40, 180, 90), (44, 33))
        return new_crop

    import server.routers.receipts as receipts_router

    monkeypatch.setattr(receipts_router.receipt_crop, "create_auto_crop", fake_auto_crop)

    response = client.post(f"/api/receipts/{receipt_id}/auto-crop", headers=headers)

    assert response.status_code == 200
    assert response.json() == {
        "id": receipt_id,
        "message": "auto crop rerun saved",
        "preview_url": f"/api/receipts/{receipt_id}/preview",
    }
    assert original.exists()
    assert previous_crop.exists()
    assert _audit_event(isolated_app["db_path"], "receipt.crop.auto_rerun") == {
        "event_type": "receipt.crop.auto_rerun",
        "actor_role": "user",
        "target_type": "receipt",
        "target_id": receipt_id,
        "metadata_json": "{}",
    }

    new_crop = Path(_receipt_crop_path(isolated_app["db_path"], receipt_id))
    assert new_crop == tmp_path / "synthetic-auto-rerun.jpg"
    assert new_crop.exists()

    preview_response = client.get(f"/api/receipts/{receipt_id}/preview", headers=headers)
    assert preview_response.status_code == 200
    assert preview_response.headers["cache-control"] == "no-store"
    with Image.open(io.BytesIO(preview_response.content)) as image:
        assert image.size == (44, 33)
        red, green, blue = image.getpixel((0, 0))
        assert 35 <= red <= 45
        assert 175 <= green <= 185
        assert 85 <= blue <= 95


def test_reset_and_auto_crop_reject_other_users_receipts(
    isolated_app,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    _insert_user(isolated_app["db_path"], "SYN002", "1002")
    other_headers = _login(client, "SYN002")

    original = tmp_path / "synthetic-original.png"
    _save_image(original)
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    def fail_if_called(source_path: Path) -> Path:
        raise AssertionError(f"auto crop should not run for unauthorized receipt: {source_path}")

    import server.routers.receipts as receipts_router

    monkeypatch.setattr(receipts_router.receipt_crop, "create_auto_crop", fail_if_called)

    reset_response = client.post(f"/api/receipts/{receipt_id}/reset-crop", headers=other_headers)
    auto_crop_response = client.post(f"/api/receipts/{receipt_id}/auto-crop", headers=other_headers)

    assert reset_response.status_code == 404
    assert auto_crop_response.status_code == 404
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None


def test_manual_crop_rejects_other_users_receipts(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    _insert_user(isolated_app["db_path"], "SYN002", "1002")
    other_headers = _login(client, "SYN002")

    original = tmp_path / "synthetic-original.png"
    _save_image(original)
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    original_response = client.get(f"/api/receipts/{receipt_id}/original", headers=other_headers)
    crop_response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=other_headers,
        json={"x": 1, "y": 1, "width": 10, "height": 10},
    )

    assert original_response.status_code == 404
    assert crop_response.status_code == 404
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None


def test_manual_crop_rejects_out_of_bounds_rect_without_updating_receipt(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    _save_image(original)
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 90, "y": 10, "width": 20, "height": 20},
    )

    assert response.status_code == 400
    assert "bounds" in response.json()["detail"]
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None


def test_manual_crop_applies_clockwise_rotation_before_cropping(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-grid.png"
    _save_quadrant_image(original)
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 2, "y": 0, "width": 1, "height": 1, "rotation_degrees": 90},
    )

    assert response.status_code == 200
    new_crop = Path(_receipt_crop_path(isolated_app["db_path"], receipt_id))
    with Image.open(new_crop) as image:
        assert image.size == (1, 1)
        red, green, blue = image.getpixel((0, 0))
        assert red >= 250
        assert green <= 5
        assert blue <= 5


def test_manual_crop_accepts_fine_rotation_and_expanded_crop_space(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-fine-rotation.png"
    _save_image(original, size=(100, 80))
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 101, "y": 1, "width": 5, "height": 10, "rotation_degrees": 10.5},
    )

    assert response.status_code == 200
    new_crop = Path(_receipt_crop_path(isolated_app["db_path"], receipt_id))
    with Image.open(new_crop) as image:
        assert image.size == (5, 10)


def test_manual_crop_uses_pillow_expanded_fine_rotation_bounds(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-pillow-expanded-bounds.png"
    _save_image(original, size=(100, 80))
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 113, "y": 97, "width": 1, "height": 1, "rotation_degrees": 10.5},
    )

    assert response.status_code == 200
    new_crop = Path(_receipt_crop_path(isolated_app["db_path"], receipt_id))
    with Image.open(new_crop) as image:
        assert image.size == (1, 1)


def test_manual_crop_rejects_out_of_range_rotation_without_updating_receipt(isolated_app, tmp_path: Path) -> None:
    client = isolated_app["client"]
    _create_receipts_table(isolated_app["db_path"])
    owner_id = _insert_user(isolated_app["db_path"], "SYN001", "1001")
    headers = _login(client, "SYN001")

    original = tmp_path / "synthetic-original.png"
    _save_image(original)
    receipt_id = _insert_receipt(isolated_app["db_path"], owner_id, "1001", original)

    response = client.post(
        f"/api/receipts/{receipt_id}/crop",
        headers=headers,
        json={"x": 1, "y": 1, "width": 10, "height": 10, "rotation_degrees": 720},
    )

    assert response.status_code == 400
    assert "rotation" in response.json()["detail"]
    assert _receipt_crop_path(isolated_app["db_path"], receipt_id) is None
