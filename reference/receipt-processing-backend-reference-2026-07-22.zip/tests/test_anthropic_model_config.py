import importlib
import sys
from datetime import datetime
from pathlib import Path

from PIL import Image


DEFAULT_MODEL = "claude-sonnet-4-6"
MODEL_ENV_KEYS = (
    "ANTHROPIC_MODEL_IMAGE_PARSE",
    "ANTHROPIC_MODEL_PDF_PARSE",
    "ANTHROPIC_MODEL_CROP_DETECT",
)


class _TextBlock:
    def __init__(self, text: str):
        self.text = text


class _Usage:
    input_tokens = 1
    output_tokens = 1


class _Message:
    def __init__(self, text: str = "{}"):
        self.content = [_TextBlock(text)]
        self.usage = _Usage()


class _Messages:
    def __init__(self, text: str = "{}"):
        self.text = text
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        return _Message(self.text)


class _Client:
    def __init__(self, messages: _Messages):
        self.messages = messages


def _purge(prefix: str) -> None:
    for module_name in list(sys.modules):
        if module_name == prefix or module_name.startswith(f"{prefix}."):
            sys.modules.pop(module_name, None)


def _import_bot_module(monkeypatch, module_name: str, **env):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "test-token")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-anthropic-key")
    monkeypatch.setenv("ADMIN_TELEGRAM_ID", "1")
    for key in MODEL_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    _purge("bot")
    return importlib.import_module(module_name)


def _import_server_module(monkeypatch, module_name: str, **env):
    monkeypatch.setenv("APP_ENV", "test")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-anthropic-key")
    for key in MODEL_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    _purge("server")
    return importlib.import_module(module_name)


def test_bot_anthropic_model_config_defaults_to_current_model(monkeypatch):
    config = _import_bot_module(monkeypatch, "bot.config")

    assert config.DEFAULT_ANTHROPIC_MODEL == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_IMAGE_PARSE == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_PDF_PARSE == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_CROP_DETECT == DEFAULT_MODEL


def test_server_anthropic_model_config_defaults_to_current_model(monkeypatch):
    config = _import_server_module(monkeypatch, "server.config")

    assert config.DEFAULT_ANTHROPIC_MODEL == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_IMAGE_PARSE == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_PDF_PARSE == DEFAULT_MODEL
    assert config.ANTHROPIC_MODEL_CROP_DETECT == DEFAULT_MODEL


def test_anthropic_model_config_treats_blank_env_as_default(monkeypatch):
    bot_config = _import_bot_module(
        monkeypatch,
        "bot.config",
        ANTHROPIC_MODEL_IMAGE_PARSE="  ",
        ANTHROPIC_MODEL_PDF_PARSE="",
        ANTHROPIC_MODEL_CROP_DETECT="   ",
    )
    server_config = _import_server_module(
        monkeypatch,
        "server.config",
        ANTHROPIC_MODEL_IMAGE_PARSE="  ",
        ANTHROPIC_MODEL_PDF_PARSE="",
        ANTHROPIC_MODEL_CROP_DETECT="   ",
    )

    assert bot_config.ANTHROPIC_MODEL_IMAGE_PARSE == DEFAULT_MODEL
    assert bot_config.ANTHROPIC_MODEL_PDF_PARSE == DEFAULT_MODEL
    assert bot_config.ANTHROPIC_MODEL_CROP_DETECT == DEFAULT_MODEL
    assert server_config.ANTHROPIC_MODEL_IMAGE_PARSE == DEFAULT_MODEL
    assert server_config.ANTHROPIC_MODEL_PDF_PARSE == DEFAULT_MODEL
    assert server_config.ANTHROPIC_MODEL_CROP_DETECT == DEFAULT_MODEL


def test_bot_image_parser_passes_env_model_to_anthropic(tmp_path: Path, monkeypatch):
    vision = _import_bot_module(
        monkeypatch,
        "bot.services.vision",
        ANTHROPIC_MODEL_IMAGE_PARSE="test-image-model",
    )
    image_path = tmp_path / "synthetic-image.png"
    Image.new("RGB", (24, 16), "white").save(image_path)
    messages = _Messages('{"merchant_name": "Synthetic", "items": []}')
    monkeypatch.setattr(
        vision.anthropic,
        "Anthropic",
        lambda **kwargs: _Client(messages),
    )

    vision.parse_receipt_image(image_path, upload_dt=datetime(2026, 7, 3, 9, 0))

    assert messages.kwargs["model"] == "test-image-model"


def test_bot_pdf_parser_passes_env_model_to_anthropic(monkeypatch):
    pdf_parser = _import_bot_module(
        monkeypatch,
        "bot.services.pdf_parser",
        ANTHROPIC_MODEL_PDF_PARSE="test-pdf-model",
    )
    messages = _Messages('{"merchant_name": "Synthetic"}')
    client = _Client(messages)

    pdf_parser._parse_text(client, "synthetic pdf text")

    assert messages.kwargs["model"] == "test-pdf-model"


def test_bot_crop_detector_passes_env_model_to_anthropic(tmp_path: Path, monkeypatch):
    image_processor = _import_bot_module(
        monkeypatch,
        "bot.services.image_processor",
        ANTHROPIC_MODEL_CROP_DETECT="test-crop-model",
    )
    image_path = tmp_path / "synthetic-crop.jpg"
    image_path.write_bytes(b"synthetic image bytes")
    messages = _Messages(
        '{"top_left":{"x":1,"y":1},"top_right":{"x":10,"y":1},'
        '"bottom_right":{"x":10,"y":20},"bottom_left":{"x":1,"y":20}}'
    )
    monkeypatch.setattr(
        image_processor.anthropic,
        "Anthropic",
        lambda **kwargs: _Client(messages),
    )

    image_processor._get_corners(image_path)

    assert messages.kwargs["model"] == "test-crop-model"


def test_server_receipt_parser_passes_env_models_to_anthropic(tmp_path: Path, monkeypatch):
    receipt_parser = _import_server_module(
        monkeypatch,
        "server.services.receipt_parser",
        ANTHROPIC_MODEL_IMAGE_PARSE="server-image-model",
        ANTHROPIC_MODEL_PDF_PARSE="server-pdf-model",
    )
    image_path = tmp_path / "synthetic-server-image.png"
    Image.new("RGB", (24, 16), "white").save(image_path)
    image_messages = _Messages('{"merchant_name": "Synthetic"}')
    monkeypatch.setattr(
        receipt_parser.anthropic,
        "Anthropic",
        lambda **kwargs: _Client(image_messages),
    )

    receipt_parser.parse_image(image_path, upload_dt=datetime(2026, 7, 3, 9, 0))

    assert image_messages.kwargs["model"] == "server-image-model"

    pdf_messages = _Messages('{"merchant_name": "Synthetic"}')
    receipt_parser._parse_pdf_text(_Client(pdf_messages), "synthetic pdf text", "2026-07-03 09:00")

    assert pdf_messages.kwargs["model"] == "server-pdf-model"


def test_server_crop_detector_passes_env_model_to_anthropic(tmp_path: Path, monkeypatch):
    receipt_crop = _import_server_module(
        monkeypatch,
        "server.services.receipt_crop",
        ANTHROPIC_MODEL_CROP_DETECT="server-crop-model",
    )
    image_path = tmp_path / "synthetic-server-crop.jpg"
    image_path.write_bytes(b"synthetic image bytes")
    messages = _Messages(
        '{"top_left":{"x":1,"y":1},"top_right":{"x":10,"y":1},'
        '"bottom_right":{"x":10,"y":20},"bottom_left":{"x":1,"y":20}}'
    )
    anthropic = importlib.import_module("anthropic")
    monkeypatch.setattr(anthropic, "Anthropic", lambda **kwargs: _Client(messages))

    receipt_crop._detect_receipt_corners(image_path)

    assert messages.kwargs["model"] == "server-crop-model"
