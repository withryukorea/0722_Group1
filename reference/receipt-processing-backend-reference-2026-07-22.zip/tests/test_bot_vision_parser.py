import base64
import importlib
import io
import sys
from datetime import datetime

import anthropic
import httpx
import pytest
from PIL import Image


def _import_vision(monkeypatch):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "test-token")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-anthropic-key")
    monkeypatch.setenv("ADMIN_TELEGRAM_ID", "1")
    for module_name in ["bot.config", "bot.services.vision"]:
        sys.modules.pop(module_name, None)
    return importlib.import_module("bot.services.vision")


class _FakeTextBlock:
    def __init__(self, text: str):
        self.text = text


class _FakeUsage:
    input_tokens = 11
    output_tokens = 7


class _FakeMessage:
    def __init__(self, text: str):
        self.content = [_FakeTextBlock(text)]
        self.usage = _FakeUsage()


class _FakeMessages:
    def __init__(self, response_text: str | None = None, exc: Exception | None = None):
        self.response_text = response_text
        self.exc = exc
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        if self.exc:
            raise self.exc
        return _FakeMessage(self.response_text or "{}")


class _FakeClient:
    def __init__(self, messages: _FakeMessages):
        self.messages = messages


def _patch_anthropic(monkeypatch, vision, fake_messages: _FakeMessages):
    created = {}

    def fake_anthropic(**kwargs):
        created["kwargs"] = kwargs
        return _FakeClient(fake_messages)

    monkeypatch.setattr(vision.anthropic, "Anthropic", fake_anthropic)
    return created


def test_parse_receipt_image_resizes_and_reencodes_to_jpeg(tmp_path, monkeypatch):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "synthetic.png"
    Image.new("RGBA", (900, 2400), (40, 80, 120, 255)).save(image_path)
    fake_messages = _FakeMessages(
        '```json\n{"merchant_name":"Synthetic","date":"2026-06-24","items":[]}\n```'
    )
    created = _patch_anthropic(monkeypatch, vision, fake_messages)

    parsed, usage = vision.parse_receipt_image(
        image_path,
        upload_dt=datetime(2026, 6, 24, 9, 30),
    )

    assert parsed["merchant_name"] == "Synthetic"
    assert usage == {"input_tokens": 11, "output_tokens": 7}
    assert created["kwargs"]["timeout"] == 25.0

    image_source = fake_messages.kwargs["messages"][0]["content"][1]["source"]
    assert image_source["media_type"] == "image/jpeg"

    prepared = base64.standard_b64decode(image_source["data"])
    with Image.open(io.BytesIO(prepared)) as prepared_image:
        assert prepared_image.format == "JPEG"
        assert prepared_image.mode == "RGB"
        assert max(prepared_image.size) == 1568


def test_parse_receipt_image_resizes_narrow_tall_image_without_zero_dimension(
    tmp_path,
    monkeypatch,
):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "synthetic_tall.jpg"
    Image.new("RGB", (1, 2000), "white").save(image_path)
    fake_messages = _FakeMessages('{"merchant_name":"Synthetic","items":[]}')
    _patch_anthropic(monkeypatch, vision, fake_messages)

    vision.parse_receipt_image(image_path)

    image_source = fake_messages.kwargs["messages"][0]["content"][1]["source"]
    prepared = base64.standard_b64decode(image_source["data"])
    with Image.open(io.BytesIO(prepared)) as prepared_image:
        assert prepared_image.size == (1, 1568)


def test_parse_receipt_image_strips_fenced_json_with_outer_whitespace(tmp_path, monkeypatch):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "synthetic.jpg"
    Image.new("RGB", (120, 80), "white").save(image_path)
    fake_messages = _FakeMessages(
        '\n  ```json\n  {"error": "not_a_receipt"}\n  ```\n  '
    )
    _patch_anthropic(monkeypatch, vision, fake_messages)

    parsed, _ = vision.parse_receipt_image(image_path)

    assert parsed == {"error": "not_a_receipt"}


def test_parse_receipt_image_classifies_invalid_image_without_leaking_path_or_bytes(
    tmp_path,
    monkeypatch,
    caplog,
):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "sensitive_receipt_name_411_11.jpg"
    raw_bytes = b"not an image Private Merchant 411.11"
    image_path.write_bytes(raw_bytes)

    with caplog.at_level("WARNING", logger="bot.services.vision"):
        with pytest.raises(vision.VisionParserError) as excinfo:
            vision.parse_receipt_image(image_path)

    logs = "\n".join(record.getMessage() for record in caplog.records)
    assert excinfo.value.category == "image_prepare"
    assert "image_prepare" in str(excinfo.value)
    assert str(image_path) not in str(excinfo.value)
    assert image_path.name not in str(excinfo.value)
    assert "Private Merchant" not in str(excinfo.value)
    assert "411.11" not in str(excinfo.value)
    assert raw_bytes.decode("utf-8") not in str(excinfo.value)
    assert "vision_parse_image_prepare_failed" in logs
    assert str(image_path) not in logs
    assert image_path.name not in logs
    assert "Private Merchant" not in logs
    assert "411.11" not in logs


@pytest.mark.parametrize(
    ("raw", "category"),
    [
        ("not-json", "invalid_json"),
        ('{"merchant_name": "missing close"', "invalid_json"),
    ],
)
def test_parse_receipt_image_classifies_invalid_json(tmp_path, monkeypatch, raw, category):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "synthetic.jpg"
    Image.new("RGB", (60, 60), "white").save(image_path)
    _patch_anthropic(monkeypatch, vision, _FakeMessages(raw))

    with pytest.raises(vision.VisionParserError) as excinfo:
        vision.parse_receipt_image(image_path)

    assert excinfo.value.category == category
    assert "not-json" not in str(excinfo.value)
    assert "missing close" not in str(excinfo.value)


@pytest.mark.parametrize(
    ("api_error_factory", "category"),
    [
        (lambda: anthropic.APITimeoutError(httpx.Request("POST", "https://example.test")), "timeout"),
        (
            lambda: anthropic.AuthenticationError(
                "bad secret test-token",
                response=httpx.Response(
                    401,
                    request=httpx.Request("POST", "https://example.test"),
                ),
                body=None,
            ),
            "auth",
        ),
        (
            lambda: anthropic.RateLimitError(
                "limited",
                response=httpx.Response(
                    429,
                    request=httpx.Request("POST", "https://example.test"),
                ),
                body=None,
            ),
            "rate_limit",
        ),
    ],
)
def test_parse_receipt_image_classifies_api_failures(
    tmp_path,
    monkeypatch,
    api_error_factory,
    category,
):
    vision = _import_vision(monkeypatch)
    image_path = tmp_path / "synthetic.jpg"
    Image.new("RGB", (60, 60), "white").save(image_path)
    _patch_anthropic(monkeypatch, vision, _FakeMessages(exc=api_error_factory()))

    with pytest.raises(vision.VisionParserError) as excinfo:
        vision.parse_receipt_image(image_path)

    assert excinfo.value.category == category
    assert "test-token" not in str(excinfo.value)
